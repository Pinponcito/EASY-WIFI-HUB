module.exports = {
  PURPLE:  {hue: 75, saturation: 100},
  BLUE: {hue: 70, saturation: 100},
  WHITE: {hue: 79, saturation: 7},
  RED: {hue: 10, saturation: 100}
};
